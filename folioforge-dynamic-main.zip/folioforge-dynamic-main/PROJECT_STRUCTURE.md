# Portfolio Website - Project Structure

## Overview
A modern, responsive portfolio website showcasing full-stack development skills with clean code and beautiful design.

## Live URL
Deployed at: [Your Deployment URL]

## Pages
- **Home** (`/`) - Hero section, featured work, and call-to-action
- **About** (`/about`) - Biography, technical skills, and work experience
- **Projects** (`/projects`) - Interactive project gallery with category filters
- **Contact** (`/contact`) - Contact form with validation and contact information

## File Organization

```
src/
├── components/
│   ├── ui/              # Shadcn UI components
│   ├── Navigation.tsx   # Main navigation with mobile menu
│   └── Footer.tsx       # Site footer with links
├── pages/
│   ├── Home.tsx        # Landing page
│   ├── About.tsx       # About page
│   ├── Projects.tsx    # Projects gallery
│   ├── Contact.tsx     # Contact form
│   └── NotFound.tsx    # 404 page
├── lib/
│   └── utils.ts        # Utility functions
├── App.tsx             # Main app with routing
├── index.css           # Design system & global styles
└── main.tsx            # App entry point
```

## Design System

The project uses a comprehensive design system defined in `src/index.css` and `tailwind.config.ts`:

- **Color Palette**: Purple/blue gradient theme with semantic tokens
- **Typography**: Clean hierarchy with gradient text effects
- **Animations**: Smooth transitions, fade-ins, and glow effects
- **Components**: Custom button variants (hero, gradient) using design tokens

## Key Features

### Responsive Design
- Mobile-first approach
- Breakpoints at 768px (md) and 1024px (lg)
- Collapsible mobile navigation

### Interactive Elements
- Category filtering on Projects page
- Form validation on Contact page
- Hover effects and animations throughout
- Mobile hamburger menu with smooth transitions

### Best Practices
- Semantic HTML5 structure
- TypeScript for type safety
- Component-based architecture
- Clean, modular, and commented code
- SEO-optimized meta tags

## Technologies Used

- **Frontend**: React 18, TypeScript
- **Styling**: Tailwind CSS, Shadcn UI
- **Routing**: React Router DOM
- **Build Tool**: Vite
- **Icons**: Lucide React
- **Notifications**: Sonner

## Running Locally

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## Deployment

This project can be deployed to:
- **GitHub Pages**: Static hosting from GitHub repository
- **Netlify**: Automatic deployments with form handling
- **Vercel**: Zero-config deployments with edge functions

## Design Philosophy

The design follows modern web standards with:
- Glassmorphism effects for depth
- Gradient accents for visual interest
- Consistent spacing and typography
- Accessible color contrast
- Smooth micro-interactions

## Future Enhancements

- Blog section with MDX support
- Dark/light theme toggle
- Project detail pages
- Contact form backend integration
- Analytics integration
