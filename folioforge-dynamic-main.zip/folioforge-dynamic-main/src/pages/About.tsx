import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const About = () => {
  const skills = {
    "Frontend": ["React", "TypeScript", "Tailwind CSS", "Next.js", "Vue.js"],
    "Backend": ["Node.js", "Express", "PostgreSQL", "MongoDB", "REST APIs"],
    "Tools": ["Git", "Docker", "VS Code", "Figma", "GitHub Actions"],
  };

  const experience = [
    {
      year: "2023 - Present",
      role: "Senior Full-Stack Developer",
      company: "Tech Innovations Inc.",
      description: "Leading development of enterprise web applications, mentoring junior developers, and architecting scalable solutions.",
    },
    {
      year: "2021 - 2023",
      role: "Full-Stack Developer",
      company: "Digital Solutions Ltd.",
      description: "Built responsive web applications, integrated third-party APIs, and improved application performance by 40%.",
    },
    {
      year: "2019 - 2021",
      role: "Frontend Developer",
      company: "Creative Agency",
      description: "Developed interactive user interfaces, collaborated with designers, and maintained multiple client projects.",
    },
  ];

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="container mx-auto max-w-5xl">
        {/* Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            About <span className="text-gradient">Me</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Passionate developer with 5+ years of experience building modern web applications
          </p>
        </div>

        {/* Bio Section */}
        <Card className="mb-16 border-border bg-card animate-fade-in">
          <CardHeader>
            <CardTitle>My Story</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-muted-foreground">
            <p>
              I'm a full-stack developer based in San Francisco, specializing in building exceptional digital experiences. 
              My journey in web development began during university when I discovered my passion for creating interactive 
              and user-friendly applications.
            </p>
            <p>
              Over the years, I've had the privilege of working with startups, agencies, and enterprise companies, 
              helping them bring their visions to life through clean code and thoughtful design. I believe in writing 
              maintainable, scalable code that not only works but is also a joy to work with.
            </p>
            <p>
              When I'm not coding, you'll find me exploring new technologies, contributing to open-source projects, 
              or sharing knowledge through blog posts and mentoring.
            </p>
          </CardContent>
        </Card>

        {/* Skills Section */}
        <div className="mb-16 animate-fade-in">
          <h2 className="text-3xl font-bold mb-8 text-center">Technical Skills</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {Object.entries(skills).map(([category, items]) => (
              <Card key={category} className="border-border bg-card hover:border-primary transition-colors">
                <CardHeader>
                  <CardTitle className="text-xl">{category}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {items.map((skill) => (
                      <Badge key={skill} variant="secondary" className="text-sm">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Experience Timeline */}
        <div className="animate-fade-in">
          <h2 className="text-3xl font-bold mb-8 text-center">Experience</h2>
          <div className="space-y-6">
            {experience.map((job, index) => (
              <Card
                key={job.role}
                className="border-border bg-card hover:border-primary transition-all duration-300 animate-slide-in-right"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                    <div>
                      <CardTitle className="text-xl">{job.role}</CardTitle>
                      <p className="text-primary font-medium">{job.company}</p>
                    </div>
                    <Badge variant="outline" className="w-fit">
                      {job.year}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{job.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
