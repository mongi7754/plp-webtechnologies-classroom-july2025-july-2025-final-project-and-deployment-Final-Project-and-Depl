import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Github } from "lucide-react";

const Projects = () => {
  const [filter, setFilter] = useState("All");

  const categories = ["All", "Web Apps", "E-Commerce", "Mobile", "API"];

  const projects = [
    {
      title: "E-Commerce Platform",
      category: "E-Commerce",
      description: "A full-featured online shopping platform with payment integration, inventory management, and admin dashboard.",
      tech: ["React", "Node.js", "PostgreSQL", "Stripe"],
      github: "https://github.com",
      demo: "https://example.com",
    },
    {
      title: "Task Management System",
      category: "Web Apps",
      description: "Collaborative task management with real-time updates, drag-and-drop interface, and team collaboration features.",
      tech: ["TypeScript", "React", "Firebase", "Tailwind"],
      github: "https://github.com",
      demo: "https://example.com",
    },
    {
      title: "Weather Dashboard",
      category: "Web Apps",
      description: "Real-time weather data visualization with forecasting, interactive maps, and location-based alerts.",
      tech: ["React", "OpenWeather API", "Charts.js"],
      github: "https://github.com",
      demo: "https://example.com",
    },
    {
      title: "Restaurant POS System",
      category: "Web Apps",
      description: "Point-of-sale system for restaurants with order management, kitchen display, and sales analytics.",
      tech: ["React", "Express", "MongoDB", "Socket.io"],
      github: "https://github.com",
      demo: "https://example.com",
    },
    {
      title: "Fitness Tracking App",
      category: "Mobile",
      description: "Mobile-first fitness application for tracking workouts, nutrition, and progress with social features.",
      tech: ["React Native", "Firebase", "Redux"],
      github: "https://github.com",
      demo: "https://example.com",
    },
    {
      title: "RESTful API Service",
      category: "API",
      description: "Scalable REST API with authentication, rate limiting, and comprehensive documentation.",
      tech: ["Node.js", "Express", "PostgreSQL", "JWT"],
      github: "https://github.com",
      demo: "https://example.com",
    },
  ];

  const filteredProjects = filter === "All" 
    ? projects 
    : projects.filter(project => project.category === filter);

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="text-center mb-12 animate-fade-in-up">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            My <span className="text-gradient">Projects</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A collection of projects I've built to solve real-world problems and explore new technologies
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-3 mb-12 animate-fade-in">
          {categories.map((category) => (
            <Button
              key={category}
              variant={filter === category ? "hero" : "outline"}
              onClick={() => setFilter(category)}
              className="transition-all duration-300"
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredProjects.map((project, index) => (
            <Card
              key={project.title}
              className="border-border bg-card hover:border-primary transition-all duration-300 group animate-scale-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <CardTitle className="group-hover:text-primary transition-colors mb-2">
                      {project.title}
                    </CardTitle>
                    <Badge variant="secondary" className="mb-2">
                      {project.category}
                    </Badge>
                  </div>
                </div>
                <CardDescription className="text-base">{project.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Tech Stack */}
                  <div className="flex flex-wrap gap-2">
                    {project.tech.map((tech) => (
                      <span
                        key={tech}
                        className="px-3 py-1 text-xs rounded-full bg-secondary text-secondary-foreground"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  {/* Links */}
                  <div className="flex gap-3 pt-2">
                    <Button variant="outline" size="sm" asChild className="flex-1">
                      <a href={project.github} target="_blank" rel="noopener noreferrer">
                        <Github size={16} className="mr-2" />
                        Code
                      </a>
                    </Button>
                    <Button variant="gradient" size="sm" asChild className="flex-1">
                      <a href={project.demo} target="_blank" rel="noopener noreferrer">
                        <ExternalLink size={16} className="mr-2" />
                        Live Demo
                      </a>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {filteredProjects.length === 0 && (
          <div className="text-center py-20">
            <p className="text-xl text-muted-foreground">No projects found in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Projects;
